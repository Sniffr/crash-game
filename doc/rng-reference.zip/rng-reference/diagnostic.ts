import { crashPointFor } from "./src/rng";

function measure(rtp: number, rounds: number) {
  const config = { rtp, maxMultiplier: 10_000 };
  const seed = "deadbeef".repeat(8);
  const targets = [1.5, 2, 3, 5, 10, 50, 100];
  const hits = new Map(targets.map((t) => [t, 0]));
  let oneEx = 0;
  let payoutAt2x = 0;

  for (let i = 0; i < rounds; i++) {
    const cp = crashPointFor(seed, i, config);
    if (cp === 1.0) oneEx++;
    if (cp >= 2.0) payoutAt2x += 2.0;
    for (const t of targets) if (cp >= t) hits.set(t, hits.get(t)! + 1);
  }

  console.log(`\nconfigured rtp = ${rtp}, rounds = ${rounds.toLocaleString()}`);
  console.log(`  P(crash = 1.00x) = ${(oneEx / rounds).toFixed(4)}`);
  console.log(`  measured RTP @2x cashout = ${(payoutAt2x / rounds).toFixed(4)}`);
  console.log(`  P(crash >= m), expected rtp/m:`);
  for (const t of targets) {
    const p = hits.get(t)! / rounds;
    const expected = rtp / t;
    console.log(
      `    m=${String(t).padEnd(5)} observed=${p.toFixed(5)}  expected=${expected.toFixed(5)}`,
    );
  }
}

measure(0.97, 500_000);
measure(0.9, 500_000);
measure(0.99, 500_000);
